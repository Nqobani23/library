package com.library;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    static ArrayList<Book> library = new ArrayList<>();
    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            System.out.println("\nLibrary Menu:");
            System.out.println("1. Add Book");
            System.out.println("2. Issue Book");
            System.out.println("3. Return Book");
            System.out.println("4. View Books");
            System.out.println("5. Exit");
            System.out.print("Choose option: ");
            int choice = scanner.nextInt(); scanner.nextLine();

            switch (choice) {
                case 1 -> addBook();
                case 2 -> issueBook();
                case 3 -> returnBook();
                case 4 -> viewBooks();
                case 5 -> System.exit(0);
                default -> System.out.println("Invalid option.");
            }
        }
    }

    static void addBook() {
        System.out.print("Enter title: ");
        String title = scanner.nextLine();
        System.out.print("Enter author: ");
        String author = scanner.nextLine();
        library.add(new Book(title, author));
        System.out.println("Book added.");
    }

    static void issueBook() {
        viewBooks();
        System.out.print("Enter index to issue: ");
        int idx = scanner.nextInt(); scanner.nextLine();
        if (idx >= 0 && idx < library.size()) {
            library.get(idx).issue();
            System.out.println("Book issued.");
        } else {
            System.out.println("Invalid index.");
        }
    }

    static void returnBook() {
        viewBooks();
        System.out.print("Enter index to return: ");
        int idx = scanner.nextInt(); scanner.nextLine();
        if (idx >= 0 && idx < library.size()) {
            library.get(idx).returnBook();
            System.out.println("Book returned.");
        } else {
            System.out.println("Invalid index.");
        }
    }

    static void viewBooks() {
        if (library.isEmpty()) {
            System.out.println("No books.");
        } else {
            for (int i = 0; i < library.size(); i++) {
                System.out.println(i + ": " + library.get(i));
            }
        }
    }
}