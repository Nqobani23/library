# Library Management System

A simple Java console application to manage books in a library. Features:
- Add new books
- Issue and return books
- Display all books with status

## How to Run
Compile and run the `Main.java` file in any Java IDE or using the command line:

```bash
javac com/library/*.java
java com.library.Main
```